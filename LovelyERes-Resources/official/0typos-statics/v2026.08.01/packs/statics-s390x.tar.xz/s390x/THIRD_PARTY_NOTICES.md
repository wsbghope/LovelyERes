# Third-party notices

This bundle contains software from the projects below. The SPDX
expressions are an index; the complete upstream notices are under
`licenses/<source>/`. Upstream projects retain their copyrights.

| Source | Version | SPDX expression | Role |
| --- | --- | --- | --- |
| [busybox](https://busybox.net/downloads/busybox-1.38.0.tar.bz2) | `1.38.0` | `GPL-2.0-only` | busybox and applet links |
| [socat](http://www.dest-unreach.org/socat/download/socat-1.8.1.3.tar.gz) | `1.8.1.3` | `GPL-2.0-only` | socat |
| [dropbear](https://matt.ucc.asn.au/dropbear/releases/dropbear-2026.94.tar.bz2) | `2026.94` | `MIT AND Unlicense` | dropbearmulti and applet links; bundled libtomcrypt and libtommath |
| [iproute2](https://mirrors.edge.kernel.org/pub/linux/utils/net/iproute2/iproute2-7.1.0.tar.xz) | `7.1.0` | `GPL-2.0-only` | ip, ss, bridge, and tc |
| [wireguard-tools](https://github.com/WireGuard/wireguard-tools/archive/refs/tags/v1.0.20260223.tar.gz) | `1.0.20260223` | `GPL-2.0-only` | wg |
| [openssl](https://github.com/openssl/openssl/releases/download/openssl-3.5.7/openssl-3.5.7.tar.gz) | `3.5.7` | `Apache-2.0` | openssl; statically linked into curl, iperf3, drill, nmap, and ncat |
| [libpcap](https://www.tcpdump.org/release/libpcap-1.10.6.tar.xz) | `1.10.6` | `BSD-3-Clause` | statically linked into tcpdump, nmap, and ncat |
| [libmnl](https://www.netfilter.org/projects/libmnl/files/libmnl-1.0.5.tar.bz2) | `1.0.5` | `LGPL-2.1-or-later` | statically linked into iproute2 and ethtool |
| [libcap-ng](https://github.com/stevegrubb/libcap-ng/archive/refs/tags/v0.9.3.tar.gz) | `0.9.3` | `LGPL-2.1-or-later` | statically linked into util-linux setpriv |
| [tcpdump](https://www.tcpdump.org/release/tcpdump-4.99.6.tar.xz) | `4.99.6` | `BSD-3-Clause` | tcpdump |
| [curl](https://curl.se/download/curl-8.21.0.tar.xz) | `8.21.0` | `curl` | curl |
| [iperf3](https://downloads.es.net/pub/iperf/iperf-3.21.tar.gz) | `3.21` | `BSD-3-Clause` | iperf3 |
| [ethtool](https://mirrors.edge.kernel.org/pub/software/network/ethtool/ethtool-7.1.tar.xz) | `7.1` | `GPL-2.0-only` | ethtool |
| [strace](https://strace.io/files/7.1/strace-7.1.tar.xz) | `7.1` | `LGPL-2.1-or-later AND (GPL-2.0-only WITH Linux-syscall-note)` | strace and bundled Linux UAPI |
| [jq](https://github.com/jqlang/jq/releases/download/jq-1.8.2/jq-1.8.2.tar.gz) | `1.8.2` | `MIT AND BSD-2-Clause` | jq and bundled oniguruma |
| [ldns](https://nlnetlabs.nl/downloads/ldns/ldns-1.9.2.tar.gz) | `1.9.2` | `BSD-3-Clause` | drill |
| [mtr](https://github.com/traviscross/mtr/archive/refs/tags/v0.96.tar.gz) | `0.96` | `GPL-2.0-only` | mtr and mtr-packet |
| [can-utils](https://github.com/linux-can/can-utils/archive/refs/tags/v2025.01.tar.gz) | `2025.01` | `GPL-2.0-only OR BSD-3-Clause` | selected SocketCAN and ISO-TP tools |
| [i2c-tools](https://mirrors.edge.kernel.org/pub/software/utils/i2c-tools/i2c-tools-4.4.tar.xz) | `4.4` | `GPL-2.0-or-later AND LGPL-2.1-or-later` | selected I2C tools and statically linked libi2c code |
| [spi-tools](https://github.com/cpb-/spi-tools/archive/a19dffe44fee857124a993598caae0c85894f914.tar.gz) | `a19dffe44fee` | `GPL-2.0-only` | spi-config and spi-pipe |
| [nmap](https://nmap.org/dist/nmap-7.99.tar.bz2) | `7.99` | `LicenseRef-NPSL-0.95 AND BSD-3-Clause AND MIT AND Zlib` | nmap, ncat, core data files, and selected bundled libraries |
| [rsync](https://download.samba.org/pub/rsync/src/rsync-3.4.4.tar.gz) | `3.4.4` | `GPL-3.0-or-later AND MIT AND Zlib` | rsync with bundled popt and zlib |
| [lsof](https://github.com/lsof-org/lsof/releases/download/4.99.7/lsof-4.99.7.tar.gz) | `4.99.7` | `lsof` | lsof |
| [util-linux](https://www.kernel.org/pub/linux/utils/util-linux/v2.42/util-linux-2.42.2.tar.xz) | `2.42.2` | `GPL-2.0-only AND GPL-2.0-or-later AND LGPL-2.1-or-later` | nsenter, unshare, lsns, setpriv, findmnt, and their static util-linux libraries |

The exact source archives and checksums are recorded in `sources.lock`.
